<?php

/**
 * File: /upgrade/upgrade-1.1.php
 */
function upgrade_module_1_1($module)
{
    Configuration::updateValue('MYMODULE_NAME','update key');
    return true; // Return true if success.
}
